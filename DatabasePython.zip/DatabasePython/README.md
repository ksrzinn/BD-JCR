# Projeto de Banco de Dados em Python

Fiz um código em Python usando duas classes (Student, Database), onde o aluno tem os seguintes atributos: ID, Nome e Data de Nascimento.

Na classe Database, tenho métodos para cadastrar um aluno e para encontrar um aluno pelo seu ID.

Realizei uma simulação de cadastro com alguns alunos para poder utilizar os métodos.




|  ID              |Nome                          |Data de Nascimento                        |
|----------------|-------------------------------|-----------------------------|
|1|Aluno (i)            |19/04/2001           |


